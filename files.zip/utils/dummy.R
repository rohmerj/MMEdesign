update_data <- function(data, updater) {
  # Operates on data by reference, so no copying of data here

  new_labels <- updater$labels
  factor_levels <- updater$factor_levels

  # Reorder and delete unused columns
  cnms_remove <- setdiff(colnames(data), new_labels)
  if (length(cnms_remove) > 0) {
    message(
      paste0(
        "The columns(s) ",
        paste0(cnms_remove, collapse = ", "),
        " is not used by the model and thus removed from the data."
      )
    )
    data[, (cnms_remove) := NULL]
  }
  data.table::setcolorder(data, new_labels)

  # Reorderes the factor levels
  if (any(updater$classes == "factor")) {
    org_factor_levels <- lapply(data, levels)
    identical_levels <- mapply(FUN = "identical", org_factor_levels, factor_levels)
    if (any(!identical_levels)) {
      changed_levels <- which(!identical_levels)
      message(paste0(
        "Levels are reordered for the factor feature(s) ",
        paste0(new_labels[changed_levels], collapse = ", "), "."
      ))

      for (i in changed_levels) {
        data.table::set(data,
          j = i,
          value = factor(unlist(data[, new_labels[i], with = F], use.names = F), levels = factor_levels[[i]])
        )
      }
    }
  }

  return(NULL)
}
#' Checks that two extracted feature lists have exactly the same properties
#'
#' @param f_list_1,f_list_2 List. As extracted from either \code{get_data_specs} or \code{get_model_specs}.
#' @param use_1_as_truth Logical. If TRUE, \code{f_list_2} is compared to \code{f_list_1}, i.e. additional elements
#' is allowed in \code{f_list_2}, and if \code{f_list_1}'s feature classes contains NAs, feature class check is
#' ignored regardless of what is specified in \code{f_list_1}. If FALSE, \code{f_list_1} and \code{f_list_2} are
#' equated and they need to contain exactly the same elements. Set to TRUE when comparing a model and data, and FALSE
#' when comparing two data sets.
#'
#' @return List. The \code{f_list_1} is returned as inserted if there all check are carried out. If some info is
#' missing from \code{f_list_1}, the function continues consistency checking using \code{f_list_2} and returns that.
#'
#' @author Martin Jullum
#'
#' @keywords internal
#' @export
#'
#' @examples
#' # Load example data
#' if (requireNamespace("MASS", quietly = TRUE)) {
#'   data("Boston", package = "MASS")
#'   # Split data into test- and training data
#'   x_train <- data.table::as.data.table(head(Boston))
#'   x_train[, rad := as.factor(rad)]
#'   data_features <- get_data_specs(x_train)
#'   model <- lm(medv ~ lstat + rm + rad + indus, data = x_train)
#'
#'   model_features <- get_model_specs(model)
#'   check_features(model_features, data_features)
#' }
check_features <- function(f_list_1, f_list_2,
                           use_1_as_truth = T) {
  if (is.null(f_list_1$specs_type)) {
    f_list_1$specs_type <- "model"
  }

  if (is.null(f_list_2$specs_type)) {
    f_list_2$specs_type <- "model"
  }

  name_1 <- f_list_1$specs_type
  name_2 <- f_list_2$specs_type

  if (name_1 == name_2) { # If used in explain after a model has NA-info during check in shapr
    name_1 <- paste0(name_1, "_train")
    name_2 <- paste0(name_2, "_test")
  }

  #### Checking that labels exists if required, otherwise stop or switch ####
  NULL_1 <- is.null(f_list_1$labels)
  NULL_2 <- is.null(f_list_2$labels)

  if (NULL_2 | (NULL_1 & !use_1_as_truth)) {
    stop(paste0("The ", name_1, " or ", name_2, " have missing column names. Handle that to proceed."))
  }
  if (NULL_1 & use_1_as_truth) {
    message(paste0(
      "The specified ", name_1, " provides NULL feature labels. ",
      "The labels of ", name_2, " are taken as the truth."
    ))
    f_list_1 <- f_list_2
  }

  NA_1 <- any(is.na(f_list_1$labels))
  NA_2 <- any(is.na(f_list_2$labels))

  if ((NA_1 & NA_2) | ((NA_1 | NA_2) & !use_1_as_truth)) {
    stop(paste0("The ", name_1, " or ", name_2, " have column names that are NA. Handle that to proceed."))
  }
  if ((NA_1 & use_1_as_truth)) {
    message(paste0(
      "The specified ", name_1, " provides feature labels that are NA. ",
      "The labels of ", name_2, " are taken as the truth."
    ))
    f_list_1 <- f_list_2
  }

  # feature names must be unique
  if (any(duplicated(f_list_1$labels))) {
    stop(paste0(name_1, " must have unique column names."))
  }

  # feature names must be unique
  if (any(duplicated(f_list_2$labels))) {
    stop(paste0(name_2, " must have unique column names."))
  }


  feat_in_1_not_in_2 <- f_list_1$labels[!(f_list_1$labels %in% f_list_2$labels)]
  feat_in_2_not_in_1 <- f_list_2$labels[!(f_list_2$labels %in% f_list_1$labels)]

  # Check that the features in 1 are in 2
  if (length(feat_in_1_not_in_2) > 0) {
    stop(
      paste0(
        "Feature(s) ",
        paste0(feat_in_1_not_in_2, collapse = ", "),
        " in ", name_1, " is not in ", name_2, "."
      )
    )
  }

  # Also check that the features in 2 are in 1
  if (!use_1_as_truth) {
    if (length(feat_in_2_not_in_1) > 0) {
      stop(
        paste0(
          "Feature(s) ",
          paste0(feat_in_2_not_in_1, collapse = ", "),
          " in ", name_2, " is not in ", name_1, "."
        )
      )
    }
  }

  # Check if any features have empty names i.e ""
  if (any(f_list_1$labels == "")) {
    stop("One or more features is missing a name.")
  }

  # Order classes and factor levels in the same way as labels
  # for f_list_1
  order_1 <- match(f_list_1$labels, names(f_list_1$classes))
  f_list_1$classes <- f_list_1$classes[order_1]
  f_list_1$factor_levels <- f_list_1$factor_levels[order_1]

  # for f_list_2
  order_2 <- match(f_list_2$labels, names(f_list_2$classes))
  f_list_2$classes <- f_list_2$classes[order_2]
  f_list_2$factor_levels <- f_list_2$factor_levels[order_2]

  # Reorder f_List_2 to match f_list_1, also removing anything in the former which is not in the latter ####
  f_list_2_reordering <- match(f_list_1$labels, f_list_2$labels)

  f_list_2$labels <- f_list_2$labels[f_list_2_reordering]
  f_list_2$classes <- f_list_2$classes[f_list_2_reordering]
  f_list_2$factor_levels <- f_list_2$factor_levels[f_list_2_reordering]

  # Sorts the factor levels for easier comparison below
  f_list_1$sorted_factor_levels <- lapply(f_list_1$factor_levels, FUN = sort)
  f_list_2$sorted_factor_levels <- lapply(f_list_2$factor_levels, FUN = sort)


  #### Checking classes ####
  if (any(is.na(f_list_1$classes)) & use_1_as_truth) { # Only relevant when f_list_1 is a model
    message(paste0(
      "The specified ", name_1, " provides feature classes that are NA. ",
      "The classes of ", name_2, " are taken as the truth."
    ))
    f_list_1 <- f_list_2
  }
  # Check if f_list_1 and f_list_2 have features with the same class
  if (!identical(f_list_1$classes, f_list_2$classes)) {
    stop(paste0("The features in ", name_1, " and ", name_2, " must have the same classes."))
  }

  # Check if the features all have class "integer", "numeric" or "factor
  if (!all(f_list_1$classes %in% c("integer", "numeric", "factor"))) {
    invalid_class <- which(!(f_list_1$classes %in% c("integer", "numeric", "factor")))
    stop(paste0(
      "Feature(s) ", paste0(f_list_1$labels[invalid_class], collapse = ", "), " in ", name_1, " and ", name_2,
      " is not of class integer, numeric or factor."
    ))
  }

  #### Checking factor levels ####
  factor_classes <- which(f_list_1$classes == "factor")
  if (length(factor_classes) > 0) {
    relevant_factor_levels <- f_list_1$factor_levels[factor_classes]
    is_NA <- any(is.na(relevant_factor_levels))
    is_NULL <- any(is.null(relevant_factor_levels))
    if ((is_NA | is_NULL) & use_1_as_truth) {
      message(paste0(
        "The specified ", name_1, " provides factor feature levels that are NULL or NA. ",
        "The factor levels of ", name_2, " are taken as the truth."
      ))
      f_list_1 <- f_list_2 # Always safe to switch as f_list_2 is based on data, and extracts correctly
    }
  }

  # Checking factor levels #
  if (!identical(f_list_1$sorted_factor_levels, f_list_2$sorted_factor_levels)) {
    stop(paste0("Some levels for factor features are not present in both ", name_1, " and ", name_2, "."))
  }

  f_list_1$sorted_factor_levels <- NULL # Not needed

  return(f_list_1) #
}

#' Define feature combinations, and fetch additional information about each unique combination
#'
#' @param m Positive integer. Total number of features.
#' @param exact Logical. If \code{TRUE} all \code{2^m} combinations are generated, otherwise a
#' subsample of the combinations is used.
#' @param n_combinations Positive integer. Note that if \code{exact = TRUE},
#' \code{n_combinations} is ignored. However, if \code{m > 12} you'll need to add a positive integer
#' value for \code{n_combinations}.
#' @param weight_zero_m Numeric. The value to use as a replacement for infinite combination
#' weights when doing numerical operations.
#'
#' @return A data.table that contains the following columns:
#' \describe{
#' \item{id_combination}{Positive integer. Represents a unique key for each combination. Note that the table
#' is sorted by \code{id_combination}, so that is always equal to \code{x[["id_combination"]] = 1:nrow(x)}.}
#' \item{features}{List. Each item of the list is an integer vector where \code{features[[i]]}
#' represents the indices of the features included in combination \code{i}. Note that all the items
#' are sorted such that \code{features[[i]] == sort(features[[i]])} is always true.}
#' \item{n_features}{Vector of positive integers. \code{n_features[i]} equals the number of features in combination
#' \code{i}, i.e. \code{n_features[i] = length(features[[i]])}.}.
#' \item{N}{Positive integer. The number of unique ways to sample \code{n_features[i]} features
#' from \code{m} different features, without replacement.}
#' }
#'
#' @export
#'
#' @author Nikolai Sellereite, Martin Jullum
#'
#' @examples
#' # All combinations
#' x <- feature_combinations(m = 3)
#' nrow(x) # Equals 2^3 = 8
#'
#' # Subsample of combinations
#' x <- feature_combinations(exact = FALSE, m = 10, n_combinations = 1e2)
feature_combinations <- function(m, exact = TRUE, n_combinations = 200, weight_zero_m = 10^6) {

  # Force user to use a natural number for n_combinations if m > 13
  if (m > 13 & is.null(n_combinations)) {
    stop(
      paste0(
        "Due to computational complexity, we recommend setting n_combinations = 10 000\n",
        "if the number of features is larger than 13. Note that you can force the use of the exact\n",
        "method (i.e. n_combinations = NULL) by setting n_combinations equal to 2^m,\n",
        "where m is the number of features."
      )
    )
  }

  # Not supported for m > 30
  if (m > 30) {
    stop("Currently we are not supporting cases where the number of features is greater than 30.")
  }

  if (!exact && n_combinations > (2^m - 2)) {
    n_combinations <- 2^m - 2
    exact <- TRUE
    message(
      paste0(
        "\nn_combinations is larger than or equal to 2^m = ", 2^m, ". \n",
        "Using exact instead."
      )
    )
  }

  if (exact) {
    dt <- feature_exact(m, weight_zero_m)
  } else {
    dt <- feature_not_exact(m, n_combinations, weight_zero_m)
    stopifnot(
      data.table::is.data.table(dt),
      !is.null(dt[["p"]])
    )
    p <- NULL # due to NSE notes in R CMD check
    dt[, p := NULL]
  }

  return(dt)
}

#' @keywords internal
feature_exact <- function(m, weight_zero_m = 10^6) {
  features <- id_combination <- n_features <- shapley_weight <- N <- NULL # due to NSE notes in R CMD check

  dt <- data.table::data.table(id_combination = seq(2^m))
  combinations <- lapply(0:m, utils::combn, x = m, simplify = FALSE)
  dt[, features := unlist(combinations, recursive = FALSE)]
  dt[, n_features := length(features[[1]]), id_combination]
  dt[, N := .N, n_features]
  dt[, shapley_weight := shapley_weights(m = m, N = N, n_features, weight_zero_m)]

  return(dt)
}

#' @keywords internal
feature_not_exact <- function(m, n_combinations = 200, weight_zero_m = 10^6) {
  features <- id_combination <- n_features <- shapley_weight <- N <- NULL # due to NSE notes in R CMD check

  # Find weights for given number of features ----------
  n_features <- seq(m - 1)
  n <- sapply(n_features, choose, n = m)
  w <- shapley_weights(m = m, N = n, n_features) * n
  p <- w / sum(w)

  # Sample number of chosen features ----------
  X <- data.table::data.table(
    n_features = c(
      0,
      sample(
        x = n_features,
        size = n_combinations,
        replace = TRUE,
        prob = p
      ),
      m
    )
  )
  X[, n_features := as.integer(n_features)]

  # Sample specific set of features -------
  data.table::setkeyv(X, "n_features")
  feature_sample <- sample_features_cpp(m, X[["n_features"]])

  # Get number of occurences and duplicated rows-------
  is_duplicate <- NULL # due to NSE notes in R CMD check
  r <- helper_feature(m, feature_sample)
  X[, is_duplicate := r[["is_duplicate"]]]

  # When we sample combinations the Shapley weight is equal
  # to the frequency of the given combination
  X[, shapley_weight := r[["sample_frequence"]]]

  # Populate table and remove duplicated rows -------
  X[, features := feature_sample]
  if (any(X[["is_duplicate"]])) {
    X <- X[is_duplicate == FALSE]
  }
  X[, is_duplicate := NULL]

  # Add shapley weight and number of combinations
  X[c(1, .N), shapley_weight := weight_zero_m]
  X[, N := 1]
  ind <- X[, .I[between(n_features, 1, m - 1)]]
  X[ind, p := p[n_features]]
  X[ind, N := n[n_features]]

  # Set column order and key table
  data.table::setkeyv(X, "n_features")
  X[, id_combination := .I]
  X[, N := as.integer(N)]
  nms <- c("id_combination", "features", "n_features", "N", "shapley_weight", "p")
  data.table::setcolorder(X, nms)

  return(X)
}

#' @keywords internal
helper_feature <- function(m, feature_sample) {
  sample_frequence <- is_duplicate <- NULL # due to NSE notes in R CMD check

  x <- feature_matrix_cpp(feature_sample, m)
  dt <- data.table::data.table(x)
  cnms <- paste0("V", seq(m))
  data.table::setnames(dt, cnms)
  dt[, sample_frequence := as.integer(.N), by = cnms]
  dt[, is_duplicate := duplicated(dt)]
  dt[, (cnms) := NULL]

  return(dt)
}

#' Initiate the making of dummy variables
#'
#' @param traindata data.table or data.frame.
#'
#' @param testdata data.table or data.frame. New data that has the same
#' feature names, types, and levels as \code{traindata}.
#'
#' @return A list that contains the following entries:
#' \describe{
#' \item{feature_list}{List. Output from \code{check_features}}
#' \item{train_dummies}{A data.frame containing all of the factors in \code{traindata} as
#' one-hot encoded variables.}
#' \item{test_dummies}{A data.frame containing all of the factors in \code{testdata} as
#' one-hot encoded variables.}
#' \item{traindata_new}{Original traindata with correct column ordering and factor levels. To be passed to
#' \code{\link[shapr:shapr]{shapr}.}}
#' \item{testdata_new}{Original testdata with correct column ordering and factor levels. To be passed to
#' \code{\link[shapr:explain]{explain}.}}
#' }
#'
#' @export
#'
#' @author Annabelle Redelmeier, Martin Jullum
#'
#' @examples
#' if (requireNamespace("MASS", quietly = TRUE)) {
#'   data("Boston", package = "MASS")
#'   x_var <- c("lstat", "rm", "dis", "indus")
#'   y_var <- "medv"
#'   x_train <- as.data.frame(Boston[401:411, x_var])
#'   y_train <- Boston[401:408, y_var]
#'   x_test <- as.data.frame(Boston[1:4, x_var])
#'
#'   # convert to factors for illustational purpose
#'   x_train$rm <- factor(round(x_train$rm))
#'   x_test$rm <- factor(round(x_test$rm), levels = levels(x_train$rm))
#'
#'   dummylist <- make_dummies(traindata = x_train, testdata = x_test)
#' }
make_dummies <- function(traindata, testdata) {
  if (all(is.null(colnames(traindata)))) {
    stop(paste0("The traindata is missing column names"))
  }

  if (all(is.null(colnames(testdata)))) {
    stop(paste0("The testdata is missing column names"))
  }

  train_dt <- data.table::as.data.table(traindata)
  test_dt <- data.table::as.data.table(testdata)

  feature_list_train <- shapr::get_data_specs(train_dt)
  feature_list_test <- shapr::get_data_specs(test_dt)

  feature_list_train$specs_type <- "traindata"
  feature_list_test$specs_type <- "testdata"

  updater <- check_features(feature_list_train, feature_list_test, F)

  # Reorderes factor levels so that they match each other
  update_data(train_dt, updater)
  update_data(test_dt, updater)

  feature_list <- updater

  # Extracts the components
  factor_features <- feature_list$labels[updater$classes == "factor"]

  if (length(factor_features) > 0) {
    factor_list <- feature_list$factor_levels[factor_features]
    feature_list$contrasts_list <- lapply(train_dt[, factor_features, with = FALSE], contrasts, contrasts = FALSE)

    # get train dummies
    m <- model.frame(
      data = train_dt,
      xlev = factor_list
    )
    train_dummies <- model.matrix(
      object = ~ . + 0,
      data = m,
      contrasts.arg = feature_list$contrasts_list
    )

    # get test dummies
    m <- model.frame(
      data = test_dt,
      xlev = factor_list
    )
    test_dummies <- model.matrix(
      object = ~ . + 0,
      data = m,
      contrasts.arg = feature_list$contrasts_list
    )
  } else {
    train_dummies <- train_dt
    test_dummies <- test_dt
  }

  return(list(
    feature_list = feature_list,
    train_dummies = train_dummies, test_dummies = test_dummies, traindata_new = train_dt,
    testdata_new = test_dt
  ))
}

#' Apply dummy variables - this is an internal function intended only to be used in
#' predict_model.xgb.Booster()
#'
#' @param feature_list List. The \code{feature_list} object in the output object after running
#' \code{\link[shapr:make_dummies]{make_dummies}}
#'
#' @param testdata data.table or data.frame. New data that has the same
#' feature names, types, and levels as \code{feature_list}.
#'
#' @return A data.table with all features but where the factors in \code{testdata} are
#' one-hot encoded variables as specified in feature_list
#'
#' @author Annabelle Redelmeier, Martin Jullum
#'
#' @keywords internal
#'
apply_dummies <- function(feature_list, testdata) {
  if (all(is.null(colnames(testdata)))) {
    stop(paste0("The testdata is missing column names"))
  }
  test_dt <- data.table::as.data.table(testdata)

  feature_list_test <- get_data_specs(test_dt)

  feature_list_test$specs_type <- "testdata"

  updater <- shapr::check_features(feature_list, feature_list_test, F)

  # Reorderes factor levels so that they match
  update_data(test_dt, updater)

  factor_features <- feature_list$labels[updater$classes == "factor"] # check which features are factors

  if (length(factor_features) > 0) {
    factor_list <- feature_list$factor_levels[factor_features]

    m <- model.frame(
      data = test_dt,
      xlev = factor_list
    )

    x <- model.matrix(
      object = ~ . + 0,
      data = m,
      contrasts.arg = feature_list$contrasts_list
    )
  } else {
    x <- test_dt
  }

  return(x)
}