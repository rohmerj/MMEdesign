if (CAS == "RCP"){
	Niter2 = 3
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "SSP126_585"
	ss0[[nom_cas[1]]] = which(df.tr$x.scenario == "SSP245")
	nom_cas[2] = "SSP126_245"
	ss0[[nom_cas[2]]] = which(df.tr$x.scenario == "SSP585" | df.tr$x.scenario == "RCP85")
	nom_cas[3] = "SSP245_585"
	ss0[[nom_cas[3]]] = which(df.tr$x.scenario == "SSP126" | df.tr$x.scenario == "RCP26") 
}

if (CAS == "RCM"){
	Niter2 = 2
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "MAR"
	ss0[[nom_cas[1]]] = which(df.tr$x.RCM == "RACMO2.3p2" | df.tr$x.RCM == "SDBN1" | df.tr$x.RCM == "HIRHAM5")
	nom_cas[2] = "woMAR"
	ss0[[nom_cas[2]]] = which(df.tr$x.RCM != "RACMO2.3p2" & df.tr$x.RCM != "SDBN1" & df.tr$x.RCM != "HIRHAM5")
}

if (CAS == "KAPPA"){
	Niter2 = 2
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "Extrem" 
	ss0[[nom_cas[1]]] = which(df.tr$x.retreat == -0.37 | df.tr$x.retreat == -0.06 | df.tr$x.retreat == 0) 
	nom_cas[2] = "Narrow" 
	ss0[[nom_cas[2]]] = which(df.tr$x.retreat == -0.9705 | df.tr$x.retreat == 0.007) 
}

if (CAS == "ISM"){
	Niter2 = 2
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "woCISM" 
	ss0[[nom_cas[1]]] = which(df.tr$x.model == "CISM") 
	nom_cas[2] = "CISM" 
	ss0[[nom_cas[2]]] = which(df.tr$x.model != "CISM") 
}


