if (CAS == "RCP"){
	Niter2 = 3
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "SSP126_585"
	ss0[[nom_cas[1]]] = which(df.tr$x.scenario == "SSP245")
	nom_cas[2] = "SSP126_245"
	ss0[[nom_cas[2]]] = which(df.tr$x.scenario == "SSP585" | df.tr$x.scenario == "RCP85")
	nom_cas[3] = "SSP245_585"
	ss0[[nom_cas[3]]] = which(df.tr$x.scenario == "SSP126" | df.tr$x.scenario == "RCP26") 
}

if (CAS == "RCM"){
	Niter2 = 1
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "MAR"
	ss0[[nom_cas[1]]] = which(df.tr$x.RCM == "RACMO2.3p2" | df.tr$x.RCM == "SDBN1")
}

if (CAS == "RCM2"){
	Niter2 = 2
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "MAR"
	ss0[[nom_cas[1]]] = which(df.tr$x.RCM == "RACMO2.3p2" | df.tr$x.RCM == "SDBN1")
	nom_cas[2] = "woMAR"
	ss0[[nom_cas[2]]] = which(df.tr$x.RCM %in% c("MARv3.13-e05","MARv3.13-e55","MARv3.9","MARv3.12"))
}

if (CAS == "KAPPA"){
	Niter2 = 2
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "Kappa-int" 
	ss0[[nom_cas[1]]] = which(df.tr$x.retreat == -0.37 | df.tr$x.retreat == -0.06 | df.tr$x.retreat == 0) 
	nom_cas[2] = "Kappa-ext" 
	ss0[[nom_cas[2]]] = which(df.tr$x.retreat == -0.9705 | df.tr$x.retreat == 0.007) 
}

if (CAS == "ISM"){
	Niter2 = 2
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "woCISM" 
	ss0[[nom_cas[1]]] = which(df.tr$x.model == "CISM") 
	nom_cas[2] = "CISM" 
	ss0[[nom_cas[2]]] = which(df.tr$x.model != "CISM") 
}


if (CAS == "ISM0"){
	Niter2 = 4
	ss0 = list()
	nom_cas = NULL
	nom_cas[1] = "IMAUICE" 
	ss0[[nom_cas[1]]] = which(df.tr$x.model != "IMAUICE") 
	nom_cas[2] = "CISM" 
	ss0[[nom_cas[2]]] = which(df.tr$x.model != "CISM") 
	nom_cas[3] = "ElmerIce" 
	ss0[[nom_cas[3]]] = which(df.tr$x.model != "ElmerIce") 
	nom_cas[4] = "GISM" 
	ss0[[nom_cas[4]]] = which(df.tr$x.model != "GISM") 
}

### NOTE: regrouper: 3.71 et 3.73 ET 5.89 et 5.91

if (CAS == "GCM-SCENARIO-R1"){
	ss0 = list()
	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90
	tt = table(CC)
	Niter2 = 24
	nom_cas = NULL
	for (ii  in 1:Niter2){
		select = names(tt)[ii]
		selectN = as.numeric(select)
		selectN = round(selectN,2)
		nom = paste(selectN) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(CC == select)#names(tt)[cc])
	}
}

if (CAS == "GCM-SCENARIO-R2"){
	ss0 = list()

	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90

	tt = unique(CC)#table(CC)
	nom_cas = NULL

	set.seed(12345)
	#select = matrix(sample(names(tt),replace=F),ncol=2)
	select = cbind(
		seq(1,length((tt)),by=2),
		seq(1,length((tt)),by=2)+1
		)
	Niter2 = nrow(select)

	for (ii  in 1:Niter2){

		selectN = as.numeric((tt)[select[ii,]])
		#selectN = round(selectN,3)
		nom = NULL
		for (i in 1:2) nom = paste(nom,selectN[i]) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(df.tr$C %in% selectN)#names(tt)[cc])
	}
}

if (CAS == "GCM-SCENARIO-R3"){
	ss0 = list()

	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90

	tt = unique(CC)#table(CC)
	Niter2 = 8
	nom_cas = NULL

	#select = matrix(sample(names(tt),replace=F),ncol=3)
	select = cbind(
		seq(1,length((tt)),by=3),
		seq(1,length((tt)),by=3)+1,
		seq(1,length((tt)),by=3)+2
		)

	for (ii  in 1:Niter2){

		selectN = as.numeric((tt)[select[ii,]])
		nom = NULL
		for (i in 1:3) nom = paste(nom,selectN[i]) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(df.tr$C %in% selectN)#names(tt)[cc])
	}
}

if (CAS == "GCM-SCENARIO-R4"){
	ss0 = list()

	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90

	tt = unique(CC)
	Niter2 = 6
	nom_cas = NULL

	#select = matrix(sample(names(tt),replace=F),ncol=4)
	select = cbind(
		seq(1,length((tt)),by=4),
		seq(1,length((tt)),by=4)+1,
		seq(1,length((tt)),by=4)+2,
		seq(1,length((tt)),by=4)+3
		)

	for (ii  in 1:Niter2){

		selectN = as.numeric((tt)[select[ii,]])
		nom = NULL
		for (i in 1:4) nom = paste(nom,selectN[i]) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(df.tr$C %in% selectN)#names(tt)[cc])
	}
}


if (CAS == "GCM-SCENARIO-R6"){
	ss0 = list()

	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90

	tt = unique(CC)
	Niter2 = 4
	nom_cas = NULL

	#select = matrix(sample(names(tt),replace=F),ncol=6)
	select = cbind(
		seq(1,length((tt)),by=6),
		seq(1,length((tt)),by=6)+1,
		seq(1,length((tt)),by=6)+2,
		seq(1,length((tt)),by=6)+3,
		seq(1,length((tt)),by=6)+4,
		seq(1,length((tt)),by=6)+5
		)

	for (ii  in 1:Niter2){

		selectN = as.numeric((tt)[select[ii,]])
		nom = NULL
		for (i in 1:6) nom = paste(nom,selectN[i]) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(df.tr$C %in% selectN)#names(tt)[cc])
	}
}

if (CAS == "GCM-SCENARIO-R8"){
	ss0 = list()

	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90

	tt = unique(CC)
	Niter2 = 3
	nom_cas = NULL

	#select = matrix(sample(names(tt),replace=F),ncol=8)
	select = cbind(
		seq(1,length((tt)),by=8),
		seq(1,length((tt)),by=8)+1,
		seq(1,length((tt)),by=8)+2,
		seq(1,length((tt)),by=8)+3,
		seq(1,length((tt)),by=8)+4,
		seq(1,length((tt)),by=8)+5,
		seq(1,length((tt)),by=8)+6,
		seq(1,length((tt)),by=8)+7
		)

	for (ii  in 1:Niter2){

		selectN = as.numeric((tt)[select[ii,]])
		nom = NULL
		for (i in 1:8) nom = paste(nom,selectN[i]) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(df.tr$C %in% selectN)#names(tt)[cc])
	}
}

if (CAS == "GCM-SCENARIO-R12"){
	ss0 = list()

	CC = df.tr$C
	CC[(df.tr$C < 3.74 & df.tr$C > 3.70)] = 3.72
	CC[(df.tr$C < 5.92 & df.tr$C > 5.89)] = 5.90

	tt = unique(CC)
	Niter2 = 2
	nom_cas = NULL

	#select = matrix(sample(names(tt),replace=F),ncol=12)

	select = rbind(1:12,13:24)

	for (ii  in 1:Niter2){

		selectN = as.numeric((tt)[select[ii,]])
		nom = NULL
		for (i in 1:12) nom = paste(nom,selectN[i]) 
		nom_cas[ii] = nom
		ss0[[nom]] = which(df.tr$C %in% selectN)#names(tt)[cc])
	}
}