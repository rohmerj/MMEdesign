#### functions
tuneG <- function(X,Y,DEPTH,ETA,ROUND,HARSH=FALSE,w=NULL){

	QQ = array(0,c(length(DEPTH),length(ETA),length(ROUND)))
	Y.hat <- Y.te <- list()
	NCV = 5
	ss = list()
	if (!HARSH){
		ss0 <- matrix(sample(1:nrow(X),nrow(X),replace = F),ncol=NCV)
		for (i in 1:NCV){
			ss[[i]] = ss0[,i]
		}
	}else{
		hh = hist(df$C,breaks = NCV, plot = FALSE)
		tempC = cut(df$C, breaks=hh$breaks)
		for (ii in 1:NCV){
			ss[[ii]] = which(tempC == levels(tempC)[ii])
		}
	}
	for (ii in 1:length(DEPTH)){
	for (jj in 1:length(ETA)){
	for (kk in 1:length(ROUND)){
		for (bb in 1:NCV){
			if (length(ss[[bb]])>0){
			
			X.tr = X[-ss[[bb]],]
			Y.tr = Y[-ss[[bb]]]
			Y.te[[bb]] <- Y[ss[[bb]]]
			X.te <- X[ss[[bb]],]

			param <- list(
	    			max_depth = DEPTH[ii],
          			eta = ETA[jj]
          		)
			if (is.null(w)==FALSE){
			wB = w[-ss[[bb]]]
			modBB <- xgboost::xgboost(
 				data = X.tr,
  				label = Y.tr,
  				verbose = FALSE,
				nrounds=ROUND[kk],
				param=param,
				weight=wB  
				)
			}else{
			modBB <- xgboost::xgboost(
 				data = X.tr,
  				label = Y.tr,
  				verbose = FALSE,
				nrounds=ROUND[kk],
				param=param
				)
			}
			Y.hat[[bb]] <- as.vector(predict(modBB,newdata=X.te))

		}
		}
		yhat = unlist(Y.hat)
		yte = unlist(Y.te)
		QQ[ii,jj,kk] = 1 - mean((yhat - yte)^2) / mean((yte - mean(yte))^2)
	}
	}
	}
	return(QQ)
}

tuneGREF <- function(X,Y,DEPTH,ETA,ROUND,HARSH=FALSE,w=NULL){

	QQ = list()
	cc = 0
	yhat= yte = Y.hat <- Y.te <- list()
	NCV = 5
	ss = list()
	if (!HARSH){
		ss0 <- matrix(sample(1:nrow(X),nrow(X),replace = F),ncol=NCV)
		for (i in 1:NCV){
			ss[[i]] = ss0[,i]
		}
	}else{
		hh = hist(df$C,breaks = NCV, plot = FALSE)
		tempC = cut(df$C, breaks=hh$breaks)
		for (ii in 1:NCV){
			ss[[ii]] = which(tempC == levels(tempC)[ii])
		}
	}
	for (ii in 1:length(DEPTH)){
	for (jj in 1:length(ETA)){
	for (kk in 1:length(ROUND)){
		for (bb in 1:NCV){
			if (length(ss[[bb]])>0){
			
			X.tr = X[-ss[[bb]],]
			Y.tr = Y[-ss[[bb]]]
			Y.te[[bb]] <- Y[ss[[bb]]]
			X.te <- X[ss[[bb]],]

			param <- list(
	    			max_depth = DEPTH[ii],
          			eta = ETA[jj]
          		)
			if (is.null(w)==FALSE){
			wB = w[-ss[[bb]]]
			modBB <- xgboost::xgboost(
 				data = X.tr,
  				label = Y.tr,
  				verbose = FALSE,
				nrounds=ROUND[kk],
				param=param,
				weight=wB  
				)
			}else{
			modBB <- xgboost::xgboost(
 				data = X.tr,
  				label = Y.tr,
  				verbose = FALSE,
				nrounds=ROUND[kk],
				param=param
				)
			}
			Y.hat[[bb]] <- as.vector(predict(modBB,newdata=X.te))

		}
		}
		cc = cc + 1
		yhat[[cc]] = unlist(Y.hat)
		yte[[cc]] = unlist(Y.te)
		QQ[[cc]] = RMSE(yte[[cc]],yhat[[cc]])
	}
	}
	}
	return(list(QQ=QQ,yhat=yhat,yte=yte))
}


#### functions
tune <- function(df,MTRY,NODE,NUM,EXTRA=FALSE,w=NULL){
  
  QQ = array(0,c(length(MTRY),length(NODE),length(NUM)))
  Y.hat <- Y.te <- list()
  NCV=5
  for (ii in 1:length(MTRY)){
    for (jj in 1:length(NODE)){
      for (kk in 1:length(NUM)){
        ss <- matrix(sample(1:nrow(df),nrow(df),replace = F),ncol=NCV)
        for (bb in 1:NCV){
          #print(bb)
          #print(compt <-  compt  + 1)			
          dfBB <- df[-ss[,bb],]
          Y.te[[bb]] <- df[ss[,bb],"sl"]
          X.te <- df[ss[,bb],-which(names(df)=="sl")]
          if (EXTRA){
            modBB<-sobolMDA::ranger(
              sl ~ ., data = dfBB,
              mtry=MTRY[ii],min.node.size = NODE[jj], num.random.splits=NUM[kk],
              num.trees = 1000,splitrule="extratrees")
          }else{
		if (is.null(w)==FALSE){
		wB = w[-ss[,bb]]
            modBB<-sobolMDA::ranger(
              sl ~ ., data = dfBB,case.weights = wB,
              mtry=MTRY[ii],min.node.size = NODE[jj],
              num.trees = 1000)
		}else{
		modBB<-sobolMDA::ranger(
              sl ~ ., data = dfBB,
              mtry=MTRY[ii],min.node.size = NODE[jj],
              num.trees = 1000)
		}
          }
          Y.hat[[bb]] <- predict(modBB,X.te)$predictions
        }
        yhat = unlist(Y.hat)
        yte = unlist(Y.te)
        QQ[ii,jj,kk] = 1 - mean((yhat - yte)^2) / mean((yte - mean(yte))^2)
      }
    }
  }
  return(QQ)
}

#### functions
tuneREF <- function(df,MTRY,NODE,NUM,EXTRA=FALSE,w=NULL){
  
  QQ = list()
  Y.hat <- Y.te <- yhat <- yte <- list()
  NCV=5
  cc = 0
  for (ii in 1:length(MTRY)){
    for (jj in 1:length(NODE)){
      for (kk in 1:length(NUM)){
        ss <- matrix(sample(1:nrow(df),nrow(df),replace = F),ncol=NCV)
        for (bb in 1:NCV){
          #print(bb)
          #print(compt <-  compt  + 1)			
          dfBB <- df[-ss[,bb],]
          Y.te[[bb]] <- df[ss[,bb],"sl"]
          X.te <- df[ss[,bb],-which(names(df)=="sl")]
          if (EXTRA){
            modBB<-sobolMDA::ranger(
              sl ~ ., data = dfBB,
              mtry=MTRY[ii],min.node.size = NODE[jj], num.random.splits=NUM[kk],
              num.trees = 1000,splitrule="extratrees")
          }else{
		if (is.null(w)==FALSE){
		wB = w[-ss[,bb]]
            modBB<-sobolMDA::ranger(
              sl ~ ., data = dfBB,case.weights = wB,
              mtry=MTRY[ii],min.node.size = NODE[jj],
              num.trees = 1000)
		}else{
		modBB<-sobolMDA::ranger(
              sl ~ ., data = dfBB,
              mtry=MTRY[ii],min.node.size = NODE[jj],
              num.trees = 1000)
		}
          }
          Y.hat[[bb]] <- predict(modBB,X.te)$predictions
        }
	  cc = cc + 1
        yhat[[cc]] = unlist(Y.hat)
        yte[[cc]] = unlist(Y.te)
        QQ[[cc]] = RMSE(yte[[cc]],yhat[[cc]])
      }
    }
  }
  return(list(QQ=QQ,yhat=yhat,yte=yte))
}

#### functions
tuneREF.CUBIST <- function(df,COMIT,NEIGH,w=NULL){
  
  QQ = list()
  Y.hat <- Y.te <- yhat <- yte <- list()
  NCV=5
  cc = 0
  for (ii in 1:length(COMIT)){
    for (jj in 1:length(NEIGH)){

        ss <- matrix(sample(1:nrow(df),nrow(df),replace = F),ncol=NCV)

        for (bb in 1:NCV){
          dfBB <- df[-ss[,bb],]
          Y.te[[bb]] <- df[ss[,bb],"sl"]
          X.te <- df[ss[,bb],-which(names(df)=="sl")]
          modBB = cubist(x=dfBB[,-ncol(dfBB)], y=dfBB[,ncol(dfBB)], committees = COMIT[ii],neighbors=NEIGH[jj], control = cubistControl())
          Y.hat[[bb]] <- predict(modBB,X.te)
        }
	  cc = cc + 1
        yhat[[cc]] = unlist(Y.hat)
        yte[[cc]] = unlist(Y.te)
        QQ[[cc]] = RMSE(yte[[cc]],yhat[[cc]])
    }
  }
  return(list(QQ=QQ,yhat=yhat,yte=yte))
}


tuneC <- function(x,y,MTRY,NODE,NUM,EXTRA=FALSE){
  
  QQ = array(0,c(length(MTRY),length(NODE),length(NUM)))
  Y.hat <- Y.te <- list()
  NCV=5
  for (ii in 1:length(MTRY)){
    for (jj in 1:length(NODE)){
      for (kk in 1:length(NUM)){
        ss <- matrix(sample(1:nrow(x),nrow(x),replace = F),ncol=NCV)
        for (bb in 1:NCV){
          #print(bb)
          #print(compt <-  compt  + 1)			
          xBB <- x[-ss[,bb],]
          yBB <- y[-ss[,bb]]
          Y.te[[bb]] <- y[ss[,bb]]
          X.te <- x[ss[,bb],]
	    modBB = ranger(y = yBB, x = xBB,importance="none",mtry=MTRY[ii],min.node.size = NODE[jj],num.trees = 1000,probability = TRUE)#,splitrule="extratrees")
          P.hat <- predict(modBB,X.te)$predictions[,2]
	    Y.hat[[bb]] = ifelse(P.hat>0.5,"+1","-1")
        }
        yhat = unlist(Y.hat)
        yte = unlist(Y.te)

        #pred <- prediction(P.hat, Y.te[[bb]])
	  #perf <- performance(pred,"tpr","fpr")

        QQ[ii,jj,kk] = length(which(yhat==yte)) / length(yte)
      }
    }
  }
  return(QQ)
}


tuneH2 <- function(df,MTRY,NODE,NUM,EXTRA=FALSE,TEMP){

  NCV = 5 
  nrep = 10 
  QQ = array(0,c(length(MTRY),length(NODE),length(NUM),nrep))
  Y.hat <- Y.te <- list()
  ss = list()
  hh = hist(TEMP,breaks = NCV, plot = FALSE)
  tempC = cut(TEMP, breaks=hh$breaks)
  NN = length(levels(tempC))
  ss = list()
  ii = 5
  #for (ii in 1:NN){
    ss0 = which(tempC == levels(tempC)[ii:NN])
    #if (length(ss0)>0){
      ss[[ii]] = sample(ss0,round(length(ss0)*1),replace=FALSE) 
    #}
  #}
  
  for (ii in 1:length(MTRY)){
    for (jj in 1:length(NODE)){
      for (kk in 1:length(NUM)){
        #print(kk)
        
	  for (rep in 1:nrep){ 
	  print(rep)
        for (bb in 5:5){
          if (length(ss[[bb]])>0){
            #print(bb)
            #print(compt <-  compt  + 1)			
            dfBB <- df[-ss[[bb]],]
            Y.te[[bb]] <- df[ss[[bb]],"sl"]
            X.te <- df[ss[[bb]],-which(names(df)=="sl")]
            if (EXTRA){
              modBB<-sobolMDA::ranger(
                sl ~ ., data = dfBB,
                respect.unordered.factors=FALSE,
                mtry=MTRY[ii],min.node.size = NODE[jj], num.random.splits=NUM[kk],
                num.trees = 1000,splitrule="extratrees")
            }else{
              modBB<-sobolMDA::ranger(
                sl ~ ., data = dfBB,
                respect.unordered.factors=FALSE,
                mtry=MTRY[ii],min.node.size = NODE[jj],
                num.trees = 1000)
            }
            Y.hat[[bb]] <- predict(modBB,X.te)$predictions
          }
        }
        yhat = unlist(Y.hat)
        yte = unlist(Y.te)
        QQ[ii,jj,kk,rep] = 1 - mean((yhat - yte)^2) / mean((yte - mean(yte))^2)
	  }##rep
      }
    }
  }
  return(QQ)
}

tuneH <- function(df,MTRY,NODE,NUM,EXTRA=FALSE,TEMP){

  NCV=5 
  nrep = 10 
  QQ = array(0,c(length(MTRY),length(NODE),length(NUM),nrep))
  Y.hat <- Y.te <- list()
  ss = list()
  hh = hist(TEMP,breaks = NCV, plot = FALSE)
  tempC = cut(TEMP, breaks=hh$breaks)
  NN = length(levels(tempC))
  ss = list()
  for (ii in 1:NN){
    ss0 = which(tempC == levels(tempC)[ii])
    if (length(ss0)>0){
      ss[[ii]] = sample(ss0,round(length(ss0)*1),replace=FALSE) 
    }
  }
  
  for (ii in 1:length(MTRY)){
    for (jj in 1:length(NODE)){
      for (kk in 1:length(NUM)){
        #print(kk)
        
	  for (rep in 1:nrep){ 
	  print(rep)
        for (bb in 1:NN){
          if (length(ss[[bb]])>0){
            #print(bb)
            #print(compt <-  compt  + 1)			
            dfBB <- df[-ss[[bb]],]
            Y.te[[bb]] <- df[ss[[bb]],"sl"]
            X.te <- df[ss[[bb]],-which(names(df)=="sl")]
            if (EXTRA){
              modBB<-sobolMDA::ranger(
                sl ~ ., data = dfBB,
                respect.unordered.factors=FALSE,
                mtry=MTRY[ii],min.node.size = NODE[jj], num.random.splits=NUM[kk],
                num.trees = 1000,splitrule="extratrees")
            }else{
              modBB<-sobolMDA::ranger(
                sl ~ ., data = dfBB,
                respect.unordered.factors=FALSE,
                mtry=MTRY[ii],min.node.size = NODE[jj],
                num.trees = 1000)
            }
            Y.hat[[bb]] <- predict(modBB,X.te)$predictions
          }
        }
        yhat = unlist(Y.hat)
        yte = unlist(Y.te)
        QQ[ii,jj,kk,rep] = 1 - mean((yhat - yte)^2) / mean((yte - mean(yte))^2)
	  }##rep
      }
    }
  }
  return(QQ)
}

#plot(yte,yhat,xlab="True value SLC [cm]",ylab="Prediction SLC [cm]",cex.axis=1.5,cex.lab=1.5,pch=15,xlim=c(min(yte,yhat),max(yte,yhat)),ylim=c(min(yte,yhat),max(yte,yhat)))
#abline(0,1,lwd=2)

maxArray <- function(A){
  
  n0 = dim(A)[3]
  CC = matrix(0,n0,2)
  for (k in 1:n0){
    M = A[,,k]
    C = apply(M,2,which.max)
    M0 = NULL
    for (i in 1:ncol(M)){
      M0[i] <- M[C[i],i]
    }
    j = which.max(M0)
    i = C[j]
    CC[k,] = c(i,j)
  }
  MM = list()
  for (k in 1:n0){
    MM[[k]] = A[CC[k,1],CC[k,2],k]
  }
  kkk = which.max(MM)
  CCC = c(CC[kkk,1],CC[kkk,2],kkk)
  return(list(CC=CCC))
}