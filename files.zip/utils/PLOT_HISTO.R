PLOT_HISTO = function(df.tr, DEUX=FALSE){

if (DEUX == FALSE){

p.scenario<-ggplot(df.tr, aes(x = x.scenario))+
	  #coord_flip()+
	  xlab('Scenario')+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt
	  #ggtitle("(a)")#+ylim(0,50)

p.GCM<-ggplot(df.tr, aes(x = x.GCM))+
	  #coord_flip()+
	  xlab('GCM')+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt
	  #ggtitle("(a)")#+ylim(0,50)

p.ISM<-ggplot(df.tr, aes(x = x.model))+
	  coord_flip()+
	  xlab('ISM')+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("(a)")#+ylim(0,50)

p.rcm<-ggplot(df.tr, aes(x = x.RCM))+
	  coord_flip()+
	  xlab("RCM")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM")#+ylim(0,50)

p.elev_feedback<-ggplot(df.tr, aes(x = x.elev_feedback))+
	  coord_flip()+
        xlab("elev_feedback")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
        #ggtitle(" Elev. feedback")#+ylim(0,50)

p.rcm_init<-ggplot(df.tr, aes(x = x.RCM_init))+
	  coord_flip()+
	  xlab("RCM init")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

p.sliding<-ggplot(df.tr, aes(x = x.sliding))+
	  coord_flip()+
	  xlab("Slding law")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

p.thermodyn<-ggplot(df.tr, aes(x = x.thermodyn))+
	  coord_flip()+
	  xlab("Thermodynamics")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

p.init<-ggplot(df.tr, aes(x = x.init))+
	  coord_flip()+
	  xlab("Initialisation")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

PLTcat <- cowplot::plot_grid(
	p.ISM,
	p.rcm,
	p.rcm_init,
	p.elev_feedback, align = "hv", ncol = 2)


p.kappa<-ggplot(df.tr, aes(x = x.retreat))+
	  coord_flip()+
	  xlab(expression(paste(kappa,' [ km (',m^3, s^-1, ')x',10^-0.4,"°",C^-1,"]")))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,400)
	  #ggtitle("")#+ylim(0,50)

p.resolution<-ggplot(df.tr, aes(x = x.resolution))+
	  coord_flip()+
	  xlab("Resolution [km]")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,400)
	  #ggtitle("Resolution min. [km]")#+ylim(0,50)

p.gsat<-ggplot(df.tr, aes(x = C))+
	  coord_flip()+
        xlab("GSAT diff. [°C]")+
        geom_bar( position = position_dodge(width = 4))+theme_bw()+tt+ylim(0,400)
	  #ggtitle("GSAT diff. [°C]")#

p.init_yrs<-ggplot(df.tr, aes(x = x.init_yrs))+
	  coord_flip()+
	  xlab("Numer of years for initialisation")+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)


PLTcont <- cowplot::plot_grid(
	p.kappa,
	p.resolution,
	p.gsat,
	align = "hv", ncol = 3)

PLTnegl <- cowplot::plot_grid(
	p.init,
	p.init_yrs,
	p.thermodyn,
	p.sliding,
	align = "hv", ncol = 2)


TXT.med = paste0("Median = ",round(median(df.tr$sl),3))
TXT.q95 = paste0("",round(quantile(df.tr$sl,0.975),2))
TXT.q05 = paste0("[",round(quantile(df.tr$sl,0.05),3)," ; ",round(quantile(df.tr$sl,0.95),3), "]")
p.sle <- ggplot(df.tr, aes(x = sl))+
        xlab("Sea level contribution in 2100 [m SLE]")+
	  #ylab("Count")+
	  geom_histogram(aes(y=..density..), alpha=0.5, position="identity")+
 	  geom_density(alpha=.2,linewidth=1.25) +
        #geom_bar( position = position_dodge(width = 0.8))+
	  theme_bw()+tt+ylim(0,9)+
	  annotate("text", x = .3, y = 7.5, label = TXT.med,size = 6)+
	  annotate("text", x = .3, y = 7., label = TXT.q05,size = 6)
	  #ggtitle("GSAT diff. [°C]")#

}else{

p.scenario<-ggplot(df.tr, aes(x = x.scenario,color = design,fill = design))+
	  #coord_flip()+
	  xlab('Scenario')+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt
	  #ggtitle("(a)")#+ylim(0,50)

p.GCM<-ggplot(df.tr, aes(x = x.GCM,color = design,fill = design))+
	  #coord_flip()+
	  xlab('GCM')+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt
	  #ggtitle("(a)")#+ylim(0,50)

p.ISM<-ggplot(df.tr, aes(x = x.model,color = design,fill = design))+
	  coord_flip()+
	  xlab('ISM')+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("(a)")#+ylim(0,50)

p.rcm<-ggplot(df.tr, aes(x = x.RCM,color = design,fill = design))+
	  coord_flip()+
	  xlab("RCM")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM")#+ylim(0,50)

p.elev_feedback<-ggplot(df.tr, aes(x = x.elev_feedback,color = design,fill = design))+
	  coord_flip()+
        xlab("elev_feedback")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
        #ggtitle(" Elev. feedback")#+ylim(0,50)

p.rcm_init<-ggplot(df.tr, aes(x = x.RCM_init,color = design,fill = design))+
	  coord_flip()+
	  xlab("RCM init")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

p.sliding<-ggplot(df.tr, aes(x = x.sliding,color = design,fill = design))+
	  coord_flip()+
	  xlab("Slding law")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

p.thermodyn<-ggplot(df.tr, aes(x = x.thermodyn,color = design,fill = design))+
	  coord_flip()+
	  xlab("Thermodynamics")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

p.init<-ggplot(df.tr, aes(x = x.init,color = design,fill = design))+
	  coord_flip()+
	  xlab("Initialisation")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)

PLTcat <- cowplot::plot_grid(
	p.ISM,
	p.rcm,
	p.rcm_init,
	p.elev_feedback, align = "hv", ncol = 2)


p.kappa<-ggplot(df.tr, aes(x = x.retreat,color = design,fill = design))+
	  coord_flip()+
	  xlab(expression(paste(kappa,' [ km (',m^3, s^-1, ')x',10^-0.4,"°",C^-1,"]")))+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,400)
	  #ggtitle("")#+ylim(0,50)

p.resolution<-ggplot(df.tr, aes(x = x.resolution,color = design,fill = design))+
	  coord_flip()+
	  xlab("Resolution [km]")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,400)
	  #ggtitle("Resolution min. [km]")#+ylim(0,50)

p.gsat<-ggplot(df.tr, aes(x = C,color = design,fill = design))+
	  coord_flip()+
        xlab("GSAT diff. [°C]")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 4))+theme_bw()+tt+ylim(0,400)
	  #ggtitle("GSAT diff. [°C]")#

p.init_yrs<-ggplot(df.tr, aes(x = x.init_yrs,color = design,fill = design))+
	  coord_flip()+
	  xlab("Numer of years for initialisation")+
	  scale_colour_manual(values = c("tomato","grey"))+
	  scale_fill_manual(values = c("tomato","grey"))+
        geom_bar( position = position_dodge(width = 0.8))+theme_bw()+tt+ylim(0,1300)
	  #ggtitle("RCM init.")#+ylim(0,50)


PLTcont <- cowplot::plot_grid(
	p.kappa,
	p.resolution,
	p.gsat,
	align = "hv", ncol = 3)

PLTnegl <- cowplot::plot_grid(
	p.init,
	p.init_yrs,
	p.thermodyn,
	p.sliding,
	align = "hv", ncol = 2)

}

return(
	list(
	
		#p.kappa = p.kappa,
		#p.resolution = p.resolution,
		#p.gsat = p.gsat,

		#p.init = p.init,
		#p.init_yrs = p.init_yrs,
		#p.thermodyn = p.thermodyn,
		#p.sliding = p.sliding

		PLTcont = PLTcont,
		PLTnegl = PLTnegl
		
	)
	)

}

DIFF_HISTO = function(df.tr1,df.tr2){
	
	ou = c(
		5,6,13,#continu
		10,11,8,7
		)
	DD = NULL
	for (j in 1:length(ou)){
		if (is.factor(df.tr1[,ou[j]])==TRUE){
			h1 = 	table(df.tr1[,ou[j]])
			h2 = 	table(df.tr2[,ou[j]])
			DD[j] = max(h1-h2)
		}else{
			h1 = 	hist(df.tr1[,ou[j]],plot = FALSE)
			h2 = 	hist(df.tr2[,ou[j]], breaks = h1$breaks,plot = FALSE)
			DD[j] = mean(h1$counts-h2$counts)	
		}

	}
	return(DD)
}
