CAfct <- function(y,lo,up){
	id <- NULL
	for (i in 1:length(y)){
		id[i] <- ifelse(y[i] >= lo[i] & y[i] <= up[i], 1, 0)
	}
	sum(id)/length(y)
}
RMSE = function(yte,yhat){
	sqrt(mean((yte-yhat)^2))
}
MaxSE = function(yte,yhat){
	(max(abs(yte-yhat)))
}
RAE = function(yte,yhat){
	(mean(abs(yte-yhat)/yte))
}
MAE = function(yte,yhat){
	(mean(abs(yte-yhat)))
}
Q2 = function(yte,yhat){
	1 - sum((yte-yhat)^2) / sum((yte-mean(yte))^2)
}

NRMSE = function(yte,yhat){
	sqrt(mean((yte-yhat)^2))/diff(range(yte))
}

crps_func <- function(Y.te.BB,Qte0){
	qq = seq(0,1,by=0.05)
	nmc = length(Y.te.BB)
	cov.pi = matrix(0,length(qq),nmc)
	for (kk in 1:(length(qq))){
		quant = Qte0[,kk]
		for (imc in 1:nmc){
		if (Y.te.BB[imc] < quant[imc]){
			cov.pi[kk,imc] = (-Y.te.BB[imc]+quant[imc])*(1-qq[kk])
		}
		if (quant[imc] <= Y.te.BB[imc]){
			cov.pi[kk,imc] = (Y.te.BB[imc]-quant[imc])*(qq[kk])
		}
		}
	}
	CRPS = mean(2*apply(cov.pi,2,sum)*0.05)
	return(CRPS)
}