CA <- function(y,lo,up){
	id <- NULL
	for (i in 1:length(y)){
		id[i] <- ifelse(y[i] >= lo[i] & y[i] <= up[i], 1, 0)
	}
	sum(id)/length(y)
}

RMSE = function(yte,yhat){
	sqrt(mean((yte-yhat)^2))
}
MaxSE = function(yte,yhat){
	(max(abs(yte-yhat)))
}
RAE = function(yte,yhat){
	(mean(abs(yte-yhat)/yte))
}
MAE = function(yte,yhat){
	(mean(abs(yte-yhat)))
}
Q2 = function(yte,yhat){
	1 - sum((yte-yhat)^2) / sum((yte-mean(yte))^2)
}

NRMSE = function(yte,yhat){
	sqrt(mean((yte-yhat)^2))/diff(range(yte))
}

compute_kernel_Gaussian <- function(x, centers, sigma) {
  apply(centers, 1, function(center) {
    apply(x, 1, function(row) {
      kernel_Gaussian(row, center, sigma)
    })
  })
}

kernel_Gaussian <- function(x, y, sigma) {
  exp(- squared_euclid_distance(x, y) / (2 * sigma * sigma))
}

#' Compute Squared Euclid Distance
#'
#' @param x a numeric vector.
#' @param y a numeric vector.
#'
#' @return squared Euclid distance
squared_euclid_distance <- function(x, y) {
  sum((x - y) ^ 2)
}